import os
try:
    from bs4 import BeautifulSoup
except ImportError:
    os.system("pip install bs4")
    os.system("cls")
    print("Please restart the application.")
    exit()
try:
    import pyautogui
except ImportError:
    os.system("pip install pyautogui")
    os.system("cls")
    print("Please restart the application.")
    exit()
try:
    from pytesseract import pytesseract
except ImportError:
    os.system("pip install pytesseract")
    os.system("cls")
    print("Please restart the application.")
    exit()
from urllib.request import urlretrieve
import shutil
import requests
import keyboard


__location__ = os.path.realpath(
    os.path.join(os.getcwd(), os.path.dirname(__file__)))
width,height = pyautogui.size()
pytesseract.tesseract_cmd = os.path.join(__location__, 'Tesseract-OCR\\tesseract.exe')

def refreshDisplay():
    os.system("cls")
    print("Welcome to Tom Clancy's: Rainbow Six Siege rank getter, by That-Chicken. To get started, simply press the ; (semicolon) key whilst you have the in game leaderboard open. DO NOT spanm this, as cloudflare will assume you are trying to DDOS them, and will therefore block all requests coming from your computer.\n\n")
refreshDisplay()

while True:
    found = None
    while found != ";":
        s = str(keyboard.read_event())
        found = s[14: len(s)-1].replace("down", "").strip(" ")

    refreshDisplay()
    restart = False
    try:
        text = pytesseract.image_to_string(pyautogui.screenshot().crop( (width/2.98, height/4.2, width/2.2, height/1.2) ))
    except:
        user = os.getlogin()
        ocrpath = f"C:\\Users\\{user}\\AppData\\Local\\Programs\\Tesseract-OCR"
        if os.path.isdir(ocrpath):
            shutil.move(ocrpath, __location__)
        else:
            url = 'https://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-w64-setup-5.3.3.20231005.exe' 
            filename = 'tesseract-ocr-w64-setup-5.3.3.20231005.exe'  
            urlretrieve(url, filename)
            os.system("CLS")
            print("Please continue with Tesseract-OCR installation, as it is necessary to this functioning.")
            os.system(os.path.join(__location__, 'tesseract-ocr-w64-setup-5.3.3.20231005.exe'))
            os.system("pause")
            os.remove(os.path.join(__location__, 'tesseract-ocr-w64-setup-5.3.3.20231005.exe'))
            if os.path.isdir(ocrpath):
                shutil.move(ocrpath, __location__)
            refreshDisplay()
        restart = True
    if restart == False:

        a = text[:-1].replace("#", "").replace("%", "").replace("*", "").replace(" ", "").replace("!", "1").replace("]", "1").replace("&", "").replace("/", "1").replace('"', "").split("\n")
        for i in a:
            if i != "\n" and len(i) > 3:
                username = i.strip("\n")
                if username[0] == "4":
                    username = username[1:]
                r = requests.get(f"https://r6.tracker.network/profile/pc/{username}")

                soup = BeautifulSoup(r.text, 'html.parser')
                element_with_style = soup.find_all(style="display: flex; align-items: center; line-height: 1; font-weight: 700;")

                soup2 = BeautifulSoup(str(element_with_style), "html.parser")
                element2 = soup2.find_all(class_="trn-text--dimmed")

                if element2:
                    rank = str(element2).replace(r'[<div class="trn-text--dimmed" style="font-size: 1.5rem;">', '').replace(r'</div>]', "")
                    print(username + " - " + rank)
                else:
                    print(username + " - No rank this season")